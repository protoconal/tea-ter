import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';
import 'package:cryptography/cryptography.dart';

void main() => runApp(const App());
class App extends StatelessWidget { const App({super.key});
  @override Widget build(BuildContext context) => MaterialApp(title:'LBS v3', theme:ThemeData(useMaterial3:true), home: const Home()); }
class Home extends StatefulWidget { const Home({super.key}); @override State<Home> createState()=>_HomeState(); }
class _HomeState extends State<Home>{
  final serverCtl=TextEditingController(text:"http://localhost:8000");
  final issuerCtl=TextEditingController(text:"http://localhost:8081");
  final cellCtl=TextEditingController(text:"dpz83d");
  final bucketCtl=TextEditingController(text:"2025-10-23T00:30:00Z");
  final deviceCtl=TextEditingController(text:"flutter3");
  final attestSecretCtl=TextEditingController(text:"issuer-attest-secret");
  final msgCtl=TextEditingController(text:"hi from flutter v3");
  String output="";
  String tokenId="";
  String keyB64="";
  Future<void> mint() async{
    final mac=Hmac(sha256, utf8.encode(attestSecretCtl.text)).convert(utf8.encode(deviceCtl.text)).toString();
    final r=await http.post(Uri.parse("${issuerCtl.text}/mint"),
      headers:{"Content-Type":"application/json"},
      body:jsonEncode({"device_attest_blob":mac,"bucket":bucketCtl.text,"device_nonce":deviceCtl.text}));
    setState(()=>output="[${r.statusCode}] ${r.body}");
    if(r.statusCode==200){
      final seed=jsonDecode(r.body)["token_seed_b64"];
      tokenId=sha256.convert(base64Decode(seed)).toString();
    }
  }
  Future<void> presence() async{
    final body={"cell":cellCtl.text,"bucket":bucketCtl.text,"proof_of_work":"0000","token_id":tokenId};
    final r=await http.post(Uri.parse("${serverCtl.text}/api/presence/announce"),headers:{"Content-Type":"application/json"},body:jsonEncode(body));
    setState(()=>output="[${r.statusCode}] ${r.body}");
  }
  Future<void> kmet() async{
    final r=await http.get(Uri.parse("${serverCtl.text}/api/presence/kmet?cell=${cellCtl.text}&bucket=${bucketCtl.text}"));
    setState(()=>output="[${r.statusCode}] ${r.body}");
  }
  Future<void> getKey() async{
    final r=await http.post(Uri.parse("${serverCtl.text}/api/keys/request"),headers:{"Content-Type":"application/json"},body:jsonEncode({"cell":cellCtl.text,"bucket":bucketCtl.text}));
    setState(()=>output="[${r.statusCode}] ${r.body}");
    if(r.statusCode==200){ keyB64=jsonDecode(r.body)["key_b64"]; }
  }
  Future<void> postMsg() async{
    if(keyB64.isEmpty){ setState(()=>output="no key"); return; }
    final key=SecretKey(base64Decode(keyB64));
    final alg=AesGcm.with256bits();
    final nonce=Nonce.randomBytes(12);
    final aad=utf8.encode("${cellCtl.text}|${bucketCtl.text}");
    final secretBox=await alg.encrypt(utf8.encode(msgCtl.text), secretKey:key, nonce:nonce, aad:aad);
    final packed=base64Encode(nonce.bytes + secretBox.cipherText + secretBox.mac.bytes);
    final r=await http.post(Uri.parse("${serverCtl.text}/api/content/post"),headers:{"Content-Type":"application/json"},
      body:jsonEncode({"cell":cellCtl.text,"bucket":bucketCtl.text,"ciphertext_b64":packed}));
    setState(()=>output="[${r.statusCode}] ${r.body}");
  }
  Future<void> listMsgs() async{
    final r=await http.get(Uri.parse("${serverCtl.text}/api/content/list?cell=${cellCtl.text}&bucket=${bucketCtl.text}"));
    setState(()=>output="[${r.statusCode}] ${r.body}");
  }
  @override Widget build(BuildContext ctx){
    return Scaffold(appBar:AppBar(title:const Text("LBS v3")),
      body:Padding(padding:const EdgeInsets.all(16),child:ListView(children:[
        TextField(controller:serverCtl, decoration:const InputDecoration(labelText:"API URL")),
        TextField(controller:issuerCtl, decoration:const InputDecoration(labelText:"Issuer URL")),
        TextField(controller:cellCtl, decoration:const InputDecoration(labelText:"Cell")),
        TextField(controller:bucketCtl, decoration:const InputDecoration(labelText:"Bucket ISO")),
        TextField(controller:deviceCtl, decoration:const InputDecoration(labelText:"Device nonce")),
        TextField(controller:attestSecretCtl, decoration:const InputDecoration(labelText:"Attest secret (POC)")),
        TextField(controller:msgCtl, decoration:const InputDecoration(labelText:"Message")),
        const SizedBox(height:12),
        Wrap(spacing:8, children:[
          ElevatedButton(onPressed: mint, child: const Text("Mint (attest)")),
          ElevatedButton(onPressed: presence, child: const Text("POST presence")),
          ElevatedButton(onPressed: kmet, child: const Text("GET k_met")),
          ElevatedButton(onPressed: getKey, child: const Text("Get Key")),
          ElevatedButton(onPressed: postMsg, child: const Text("Post")),
          ElevatedButton(onPressed: listMsgs, child: const Text("List")),
        ]),
        const SizedBox(height:12),
        const Text("Output:"),
        SelectableText(output, minLines:6),
      ])));
  }
}
