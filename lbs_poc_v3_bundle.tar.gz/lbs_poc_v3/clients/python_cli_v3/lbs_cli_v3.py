#!/usr/bin/env python3
import argparse, base64, hashlib, json, os
from datetime import datetime, timezone
import requests
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

BASE32="0123456789bcdefghjkmnpqrstuvwxyz"
def geohash_encode(lat, lon, precision):
    latI=[-90.0,90.0]; lonI=[-180.0,180.0]
    gh=[]; even=True; bit=0; ch=0; bits=[16,8,4,2,1]
    while len(gh)<precision:
        if even:
            mid=(lonI[0]+lonI[1])/2
            if lon>mid: ch|=bits[bit]; lonI[0]=mid
            else: lonI[1]=mid
        else:
            mid=(latI[0]+latI[1])/2
            if lat>mid: ch|=bits[bit]; latI[0]=mid
            else: latI[1]=mid
        even=not even
        if bit<4: bit+=1
        else: gh.append(BASE32[ch]); bit=0; ch=0
    return "".join(gh)

def bucket_iso(dt, mins):
    m=(dt.minute//mins)*mins
    return dt.replace(minute=m, second=0, microsecond=0, tzinfo=timezone.utc).isoformat().replace("+00:00","Z")

def pow_solve(cell,bucket,diff_bits):
    prefix="0"*(diff_bits//4)
    while True:
        nonce=os.urandom(8).hex()
        h=hashlib.sha256(f"{cell}|{bucket}|{nonce}".encode()).hexdigest()
        if h.startswith(prefix): return nonce

def aesgcm_encrypt(key,plaintext,aad=b""):
    nonce=os.urandom(12); ct=AESGCM(key).encrypt(nonce,plaintext,aad)
    return base64.b64encode(nonce+ct).decode()

def aesgcm_decrypt(key,b64,aad=b""):
    data=base64.b64decode(b64); nonce,ct=data[:12],data[12:]
    return AESGCM(key).decrypt(nonce,ct,aad)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--server",default="http://localhost:8000")
    ap.add_argument("--issuer",default="http://localhost:8081")
    ap.add_argument("--lat",type=float,default=43.6535); ap.add_argument("--lon",type=float,default=-79.3839)
    ap.add_argument("--precision",type=int,default=6); ap.add_argument("--bucket-mins",type=int,default=10)
    ap.add_argument("--device-nonce",default="cli3"); ap.add_argument("--attest-secret",default="issuer-attest-secret")
    ap.add_argument("--message",default="hello from cli v3")
    ap.add_argument("--difficulty",type=int,default=16)
    args=ap.parse_args()

    now=datetime.now(timezone.utc)
    cell=geohash_encode(args.lat,args.lon,args.precision)
    bucket=bucket_iso(now,args.bucket_mins)

    att_mac=hashlib.sha256((args.device_nonce).encode()).hexdigest()  # wrong; use HMAC with secret below
    # Correct POC attestation: HMAC(attest_secret, device_nonce)
    import hmac
    att=hmac.new(args.attest_secret.encode(), args.device_nonce.encode(), hashlib.sha256).hexdigest()
    r=requests.post(f"{args.issuer}/mint", json={"device_attest_blob":att,"bucket":bucket,"device_nonce":args.device_nonce}, timeout=10)
    r.raise_for_status()
    seed_b64=r.json()["token_seed_b64"]
    token_id=hashlib.sha256(base64.b64decode(seed_b64)).hexdigest()

    nonce_hex=pow_solve(cell,bucket,args.difficulty)

    r=requests.post(f"{args.server}/api/presence/announce", json={"cell":cell,"bucket":bucket,"proof_of_work":nonce_hex,"token_id":token_id}, timeout=10)
    print("[presence]", r.status_code, r.text)

    r=requests.get(f"{args.server}/api/presence/kmet", params={"cell":cell,"bucket":bucket}, timeout=10)
    print("[kmet]", r.status_code, r.text)
    if not r.json().get("k_met"): print("[-] k not met"); return

    r=requests.post(f"{args.server}/api/keys/request", json={"cell":cell,"bucket":bucket}, timeout=10)
    key=base64.b64decode(r.json()["key_b64"]); key=(key+b"0"*32)[:32]

    aad=f"{cell}|{bucket}".encode()
    ct=aesgcm_encrypt(key, args.message.encode(), aad=aad)
    r=requests.post(f"{args.server}/api/content/post", json={"cell":cell,"bucket":bucket,"ciphertext_b64":ct}, timeout=10)
    print("[post]", r.status_code, r.text)

    r=requests.get(f"{args.server}/api/content/list", params={"cell":cell,"bucket":bucket}, timeout=10)
    posts=r.json()
    for i,p in enumerate(posts,1):
        try: pt=aesgcm_decrypt(key,p["ciphertext_b64"],aad=aad).decode(errors="ignore")
        except Exception as e: pt=f"(cannot decrypt: {e})"
        print(f"#{i} {p['created_at']} -> {pt}")

    # Fetch merkle proof
    r=requests.get(f"{args.server}/api/transparency/proof", params={"cell":cell,"bucket":bucket,"token_id":token_id}, timeout=10)
    if r.status_code==200:
        pr=r.json(); ok=verify_merkle(pr["leaf"], pr["root"], pr["proof"]); print("[merkle verify]", ok)

def verify_merkle(leaf_hex, root_hex, proof):
    h=bytes.fromhex(leaf_hex)
    if len(h)!=32: h=hashlib.sha256(h).digest()
    for d,ph in proof:
        phb=bytes.fromhex(ph)
        h=hashlib.sha256(h+phb).digest() if d=="R" else hashlib.sha256(phb+h).digest()
    return h.hex()==root_hex

if __name__=="__main__": main()
