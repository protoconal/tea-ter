# Merkle Tree Notes (POC)
We compute a Merkle root per (cell,bucket) from sorted token_id list.
- Leaves: SHA256(hex(token_id))
- Parent: SHA256(left || right); if odd, duplicate last
- Proof: list of {dir:'L'|'R', hash:hex}
- Verify: start with leaf = SHA256(token_id_hex), fold proof
