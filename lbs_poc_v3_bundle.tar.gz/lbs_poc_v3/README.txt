# LBS POC v3 — Full bundle
Includes:
- issuer/ (FastAPI): token issuer with attestation stub
- server_v3/ (Django): API server with Merkle transparency + VOPRF stub
- clients/python_cli_v3/: CLI using issuer + merkle proof verify + AES-GCM
- clients/flutter_v3/: Flutter app with AES-GCM posting

Quick start:
1) Start issuer and server:
   - In one terminal:
     ```
     cd server_v3
     docker compose up --build
     docker compose exec api python manage.py migrate
     ```
   (compose also builds issuer on port 8081)

2) Run Python CLI v3:
   ```
   cd clients/python_cli_v3
   pip install -r requirements.txt
   python lbs_cli_v3.py --server http://localhost:8000 --issuer http://localhost:8081
   ```

3) Run Flutter v3 (optional):
   ```
   cd clients/flutter_v3
   flutter create lbs_poc_client_v3
   cd lbs_poc_client_v3
   cp ../lib/main.dart lib/main.dart
   cp ../pubspec.yaml pubspec.yaml
   flutter pub get
   flutter run -d chrome
   ```

Notes:
- VOPRF endpoint is a stub; replace with RFC 9381 implementation.
- Attestation is a POC HMAC; swap with Android/iOS attestation and Privacy Pass issuer.
- Merkle transparency provides root and inclusion proofs for (cell,bucket).
