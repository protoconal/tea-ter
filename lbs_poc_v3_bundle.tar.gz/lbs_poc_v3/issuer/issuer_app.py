from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import os, hmac, hashlib, base64

ISSUER_SECRET = os.getenv("ISSUER_SECRET","issuer-attest-secret")
app = FastAPI(title="Token Issuer (POC)")

class MintRequest(BaseModel):
    device_attest_blob: str  # POC: HMAC(attest_secret, device_nonce)
    bucket: str
    device_nonce: str

class MintResponse(BaseModel):
    token_seed_b64: str  # POC seed that API will blind/sign in server

@app.post("/mint", response_model=MintResponse)
def mint(req: MintRequest):
    # POC "attestation": verify device_attest_blob == HMAC(secret, device_nonce)
    mac = hmac.new(ISSUER_SECRET.encode(), req.device_nonce.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(mac, req.device_attest_blob):
        raise HTTPException(401, "attestation_failed")
    # Return a per-bucket seed (opaque to client). Real system would return blind-signing cap.
    seed = hmac.new(ISSUER_SECRET.encode(), f"{req.device_nonce}|{req.bucket}".encode(), hashlib.sha256).digest()
    return MintResponse(token_seed_b64=base64.b64encode(seed).decode())
