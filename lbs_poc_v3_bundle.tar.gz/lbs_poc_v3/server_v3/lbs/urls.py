from django.urls import path, include
from api import views as v
urlpatterns=[
  path("api/presence/announce", v.presence_announce),
  path("api/presence/kmet", v.kmet),
  path("api/keys/request", v.keys_request),
  path("api/content/post", v.post_create),
  path("api/content/list", v.post_list),
  path("api/transparency/root", v.transparency_root),
  path("api/transparency/proof", v.transparency_proof),
  path("api/voprf/evaluate", v.voprf_evaluate),  # stub
]
