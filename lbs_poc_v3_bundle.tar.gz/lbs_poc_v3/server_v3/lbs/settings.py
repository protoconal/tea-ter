import os
from pathlib import Path
from urllib.parse import urlparse
BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = os.getenv("DJANGO_SECRET_KEY","dev")
DEBUG = os.getenv("DEBUG","1")=="1"
ALLOWED_HOSTS = ["*"]
INSTALLED_APPS = ["django.contrib.admin","django.contrib.auth","django.contrib.contenttypes","django.contrib.sessions","django.contrib.messages","django.contrib.staticfiles","rest_framework","api"]
MIDDLEWARE = ["django.middleware.security.SecurityMiddleware","django.contrib.sessions.middleware.SessionMiddleware","django.middleware.common.CommonMiddleware","django.middleware.csrf.CsrfViewMiddleware","django.contrib.auth.middleware.AuthenticationMiddleware","django.contrib.messages.middleware.MessageMiddleware","django.middleware.clickjacking.XFrameOptionsMiddleware"]
ROOT_URLCONF = "lbs.urls"
TEMPLATES = [{"BACKEND":"django.template.backends.django.DjangoTemplates","DIRS":[BASE_DIR/"templates"],"APP_DIRS":True,"OPTIONS":{"context_processors":["django.template.context_processors.request","django.contrib.auth.context_processors.auth","django.contrib.messages.context_processors.messages"]}}]
WSGI_APPLICATION = "lbs.wsgi.application"
parsed = urlparse(os.getenv("DATABASE_URL","postgres://django:django@localhost:5432/lbs"))
DATABASES={"default":{"ENGINE":"django.db.backends.postgresql","NAME":parsed.path.lstrip("/"),"USER":parsed.username,"PASSWORD":parsed.password,"HOST":parsed.hostname,"PORT":parsed.port or 5432}}
STATIC_URL="static/"
K_MIN=int(os.getenv("K_MIN","3"))
DP_EPSILON=float(os.getenv("DP_EPSILON","1.0"))
POW_DIFFICULTY=int(os.getenv("POW_DIFFICULTY","16"))
ISSUER_URL=os.getenv("ISSUER_URL","http://localhost:8081")
SERVER_PRF_SECRET=os.getenv("SERVER_PRF_SECRET","server-prf")
