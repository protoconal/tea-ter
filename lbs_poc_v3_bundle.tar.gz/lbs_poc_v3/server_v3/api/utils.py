import hashlib, hmac, json, base64, math, random
from django.conf import settings
def pow_ok(cell,bucket,nonce_hex,diff_bits):
    prefix="0"*(diff_bits//4)
    h=hashlib.sha256(f"{cell}|{bucket}|{nonce_hex}".encode()).hexdigest()
    return h.startswith(prefix)
def prf_key(cell,bucket):
    return hmac.new(settings.SERVER_PRF_SECRET.encode(), f"{cell}|{bucket}".encode(), hashlib.sha256).digest()
def dp_laplace(eps):
    u=random.random()-0.5
    return -math.copysign(1.0,u)*math.log(1-2*abs(u))/eps
# Merkle helpers
def merkle_root_hex(leaves_hex):
    if not leaves_hex: return "0"*64
    layer=[bytes.fromhex(h) for h in leaves_hex]
    if any(len(x)!=32 for x in layer): layer=[hashlib.sha256(x).digest() for x in layer]
    while len(layer)>1:
        nxt=[]
        for i in range(0,len(layer),2):
            a=layer[i]; b=layer[i+1] if i+1<len(layer) else layer[i]
            nxt.append(hashlib.sha256(a+b).digest())
        layer=nxt
    return layer[0].hex()
def merkle_proof(leaves_hex, index):
    layer=[bytes.fromhex(h) for h in leaves_hex]
    if any(len(x)!=32 for x in layer): layer=[hashlib.sha256(x).digest() for x in layer]
    proof=[]
    idx=index
    while len(layer)>1:
        nxt=[]
        for i in range(0,len(layer),2):
            a=layer[i]; b=layer[i+1] if i+1<len(layer) else layer[i]
            if i==idx or i+1==idx:
                if i==idx: proof.append(("R",(b.hex())))
                else: proof.append(("L",(a.hex())))
                idx=i//2
            nxt.append(hashlib.sha256(a+b).digest())
        layer=nxt
    return proof
def verify_proof(leaf_hex, root_hex, proof):
    h=bytes.fromhex(leaf_hex)
    if len(h)!=32: h=hashlib.sha256(h).digest()
    for dir,ph in proof:
        phb=bytes.fromhex(ph)
        h=hashlib.sha256(h+phb).digest() if dir=="R" else hashlib.sha256(phb+h).digest()
    return h.hex()==root_hex
