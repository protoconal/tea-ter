from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from django.db.models import Count
from .models import Presence, EncryptedPost
from .utils import pow_ok, prf_key, dp_laplace, merkle_root_hex, merkle_proof, verify_proof
import json, hashlib, base64, requests

@csrf_exempt
def presence_announce(req):
    if req.method!="POST": return JsonResponse({"error":"POST"}, status=405)
    body=json.loads(req.body.decode())
    cell, bucket = body.get("cell"), body.get("bucket")
    token_id, pow_nonce = body.get("token_id"), body.get("proof_of_work")
    if not pow_ok(cell,bucket,pow_nonce, settings.POW_DIFFICULTY):
        return JsonResponse({"error":"pow_invalid"}, status=400)
    try:
        Presence.objects.create(cell=cell,bucket=bucket,token_id=token_id)
    except Exception:
        pass
    return JsonResponse({"ok":True})

def kmet(req):
    cell=req.GET.get("cell"); bucket=req.GET.get("bucket")
    count=Presence.objects.filter(cell=cell,bucket=bucket).values("token_id").distinct().count()
    noisy=max(0, int(round(count + dp_laplace(settings.DP_EPSILON))))
    return JsonResponse({"k_met": count>=settings.K_MIN, "noisy_count": noisy, "k_min": settings.K_MIN})

@csrf_exempt
def keys_request(req):
    if req.method!="POST": return JsonResponse({"error":"POST"}, status=405)
    body=json.loads(req.body.decode())
    cell, bucket = body.get("cell"), body.get("bucket")
    count=Presence.objects.filter(cell=cell,bucket=bucket).values("token_id").distinct().count()
    if count < settings.K_MIN:
        return JsonResponse({"error":"k_not_met"}, status=403)
    key=prf_key(cell,bucket)  # VOPRF stub
    return JsonResponse({"key_b64": base64.b64encode(key).decode()})

@csrf_exempt
def post_create(req):
    if req.method!="POST": return JsonResponse({"error":"POST"}, status=405)
    body=json.loads(req.body.decode())
    EncryptedPost.objects.create(cell=body["cell"],bucket=body["bucket"],ciphertext_b64=body["ciphertext_b64"])
    return JsonResponse({"ok":True}, status=201)

def post_list(req):
    cell=req.GET.get("cell"); bucket=req.GET.get("bucket")
    qs=EncryptedPost.objects.filter(cell=cell,bucket=bucket).order_by("created_at")
    return JsonResponse([{"ciphertext_b64":q.ciphertext_b64,"created_at":q.created_at.isoformat()} for q in qs], safe=False)

def transparency_root(req):
    cell=req.GET.get("cell"); bucket=req.GET.get("bucket")
    tokens=list(Presence.objects.filter(cell=cell,bucket=bucket).values_list("token_id", flat=True))
    leaves=[hashlib.sha256(bytes.fromhex(t)).hexdigest() if len(t)==64 else hashlib.sha256(t.encode()).hexdigest() for t in tokens]
    root=merkle_root_hex([l for l in leaves])
    return JsonResponse({"root": root, "count": len(tokens)})

def transparency_proof(req):
    cell=req.GET.get("cell"); bucket=req.GET.get("bucket"); tid=req.GET.get("token_id")
    tokens=list(Presence.objects.filter(cell=cell,bucket=bucket).values_list("token_id", flat=True))
    leaves=[hashlib.sha256(bytes.fromhex(t)).hexdigest() if len(t)==64 else hashlib.sha256(t.encode()).hexdigest() for t in tokens]
    if tid in tokens: idx=tokens.index(tid)
    else: return JsonResponse({"error":"not_found"}, status=404)
    root=merkle_root_hex(leaves); proof=merkle_proof(leaves, idx)
    return JsonResponse({"root":root, "proof": proof, "leaf": leaves[idx]})

@csrf_exempt
def voprf_evaluate(req):
    # STUB: returns PRF(cell|bucket). Replace with RFC 9381 implementation.
    if req.method!="POST": return JsonResponse({"error":"POST"}, status=405)
    body=json.loads(req.body.decode())
    x=body.get("input","")
    dig=hashlib.sha256((x+"|stub").encode()).digest()
    return JsonResponse({"out_b64": base64.b64encode(dig).decode()})
