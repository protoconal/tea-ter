# Privacy-Preserving Location Social — System Overview (POC)

This document summarizes our architecture and choices so far, and shows where we will swap in stronger primitives or P2P later.

## Goals
- Server never learns precise user locations.
- Clients learn only (cell, time-bucket) counts and content keys if k-anonymity is met.
- E2E encryption for all content; storage sees ciphertext only.
- Sybil attacks are expensive; buckets are auditable via transparency headers.

## High-Level Flow
```mermaid
sequenceDiagram
    participant Client
    participant Presence as Presence API
    participant KeySvc as Key Service
    participant Store as Content Store

    Client->>Presence: POST /presence/announce {cell, bucket, token}
    Presence-->>Client: 200 OK

    Client->>Presence: GET /presence/kmet?cell&bucket
    Presence-->>Client: {k_met, floor, header, header_sig}

    alt k_met
      Client->>KeySvc: POST /keys/request {cell, bucket, token}
      KeySvc-->>Client: {key_b64, header, header_sig}
      Client->>Store: POST /content/post {cell, bucket, ciphertext}
      Client->>Store: GET /content/list?cell&bucket
      Store-->>Client: [ciphertexts...]
      Client->>Client: Decrypt locally with key
    else not met
      Client->>Client: Coarsen cell or wait for more users
    end
```

## Data Model
```mermaid
classDiagram
class Presence {
  +id
  +cell: string
  +bucket: string
  +device_nonce: string (unique per bucket)
  +created_at: datetime
}
class EncryptedPost {
  +id
  +cell: string
  +bucket: string
  +ciphertext_b64: text
  +created_at: datetime
}
Presence "1" --> "many" EncryptedPost : same (cell,bucket)
```

## Threat Model & Controls
- Honest-but-curious server; external attacker; malicious users.
- Controls:
  - No raw GPS ever leaves device.
  - Per-bucket tokens (replace POC HMAC with blind tokens).
  - k-gating before key issuance.
  - E2EE content; short TTLs.
  - Transparency headers (later: Merkle roots + append-only feed).

## Swap-in Points (Roadmap)
- Privacy Pass tokens after device attestation -> replace verify_poc_token().
- VOPRF-derived keys -> replace derive_room_key().
- Merkle commitments & feed -> replace sign_header() + header endpoints.
- DP counts -> Presence returns boolean / capped ">=k" with small DP noise.
- Abuse -> quotas, PoW/stake, ASN caps, anomaly quarantine.

## P2P-Ready Hooks
- Client already uses cell/time locally; server only sees coarse presence.
- You can replace Key Service with:
  - DKG/MLS per (cell,bucket), or
  - Committee-based k-proof with per-bucket pseudonyms.
- Discovery: PSI over (cell,bucket) on a region pubsub before joining a room.

## API Cheatsheet
- POST /api/presence/announce — presence (one per device per bucket)
- GET  /api/presence/kmet?cell&bucket — { k_met, floor, header_sig }
- POST /api/keys/request — returns key_b64 if k_met
- POST /api/content/post — stores ciphertext
- GET  /api/content/list?cell&bucket — lists ciphertexts
- GET  /api/transparency/header?cell&bucket — signed header (count)

## Mobile Framework Recommendation
- Flutter for single codebase (iOS/Android/Web), strong performance, good crypto/FFI.
- Alternatives: React Native (Expo) for web-heavy teams; Kotlin Multiplatform if you prefer near-native.

## Bucketing & K
```mermaid
flowchart LR
    A[GPS on device] --> B[Geohash/H3 cell at multiple precisions]
    B --> C[floor timestamp to 10-min bucket]
    C --> D[Generate per-bucket anonymous token]
    D --> E[POST presence]
    E --> F[GET k_met]
    F -- false --> B
    F -- true --> G[Request room key]
    G --> H[Encrypt & post]
    H --> I[List & decrypt]
```

## Security Notes
- Lock one precision per device per bucket (server-enforced).
- Rate-limit presence and key requests; budget per device & per ASN.
- Strip EXIF from media client-side; add jitter/cover traffic.
- Keep logs minimal; drop tokens after use.
