# Client & Docs Bundle

This bundle contains:
- python_cli/ — a Python CLI client that exercises the Django POC end-to-end (presence -> k-met -> key -> encrypt/post -> list/decrypt).
- flutter_starter/ — a minimal Flutter starter UI to call the same endpoints.
- docs/OVERVIEW.md — architecture summary with diagrams (Mermaid).

## Python CLI
```bash
cd python_cli
pip install -r requirements.txt
python lbs_cli.py --server http://localhost:8000 --lat 43.6535 --lon -79.3839 --precision 6 --device-nonce cli1
```

## Flutter
See flutter_starter/README.md. Replace your project's lib/main.dart and pubspec.yaml with those provided here, then flutter pub get and run.

## Note
These clients target the POC Django server we created earlier. Swap-in steps for blind tokens, VOPRF keys, and transparency log are noted in the docs.
