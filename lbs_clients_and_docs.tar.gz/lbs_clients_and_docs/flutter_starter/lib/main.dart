import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LBS POC Client',
      theme: ThemeData(useMaterial3: true),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final serverCtl = TextEditingController(text: "http://localhost:8000");
  final cellCtl = TextEditingController(text: "dpz83d");
  final bucketCtl = TextEditingController(text: "2025-10-23T00:30:00Z");
  final nonceCtl = TextEditingController(text: "flutter1");
  final attestSecretCtl = TextEditingController(text: "attest-secret-change-me");
  final messageCtl = TextEditingController(text: "hi from Flutter");

  String token = "";
  String output = "";
  String roomKeyB64 = "";
  bool kMet = false;

  Future<void> genToken() async {
    final nonce = nonceCtl.text.trim();
    final bucket = bucketCtl.text.trim();
    final secret = attestSecretCtl.text;
    final mac = Hmac(sha256, utf8.encode(secret))
        .convert(utf8.encode("$nonce|$bucket"))
        .toString();
    final raw = "$nonce|$bucket|$mac";
    token = base64Url.encode(utf8.encode(raw)).replaceAll("=", "");
    setState(() {});
  }

  Future<void> announce() async {
    final uri = Uri.parse("${serverCtl.text}/api/presence/announce");
    final r = await http.post(uri,
      headers: {"Content-Type":"application/json"},
      body: jsonEncode({"cell": cellCtl.text, "bucket": bucketCtl.text, "token": token})
    );
    setState(() { output = "[${r.statusCode}] ${r.body}"; });
  }

  Future<void> kmetCall() async {
    final c = cellCtl.text; final b = bucketCtl.text;
    final uri = Uri.parse("${serverCtl.text}/api/presence/kmet?cell=$c&bucket=$b");
    final r = await http.get(uri);
    kMet = false; roomKeyB64 = "";
    if (r.statusCode == 200) {
      final data = jsonDecode(r.body);
      kMet = data["k_met"] == true;
    }
    setState(() { output = "[${r.statusCode}] ${r.body}"; });
  }

  Future<void> getKey() async {
    final uri = Uri.parse("${serverCtl.text}/api/keys/request");
    final r = await http.post(uri,
      headers: {"Content-Type":"application/json"},
      body: jsonEncode({"cell": cellCtl.text, "bucket": bucketCtl.text, "token": token})
    );
    if (r.status_code == 200) { /* dart ignore */ }
    if (r.statusCode == 200) {
      final data = jsonDecode(r.body);
      roomKeyB64 = data["key_b64"] ?? "";
    }
    setState(() { output = "[${r.statusCode}] ${r.body}"; });
  }

  Future<void> postMsg() async {
    final ct = base64Encode(utf8.encode(messageCtl.text)); // placeholder "ciphertext"
    final uri = Uri.parse("${serverCtl.text}/api/content/post");
    final r = await http.post(uri,
      headers: {"Content-Type":"application/json"},
      body: jsonEncode({"cell": cellCtl.text, "bucket": bucketCtl.text, "ciphertext_b64": ct})
    );
    setState(() { output = "[${r.statusCode}] ${r.body}"; });
  }

  Future<void> listMsg() async {
    final c = cellCtl.text; final b = bucketCtl.text;
    final uri = Uri.parse("${serverCtl.text}/api/content/list?cell=$c&bucket=$b");
    final r = await http.get(uri);
    setState(() { output = "[${r.statusCode}] ${r.body}"; });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("LBS POC Client")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(controller: serverCtl, decoration: const InputDecoration(labelText: "Server URL")),
            TextField(controller: cellCtl, decoration: const InputDecoration(labelText: "Cell (geohash)")),
            TextField(controller: bucketCtl, decoration: const InputDecoration(labelText: "Bucket (ISO UTC)")),
            TextField(controller: nonceCtl, decoration: const InputDecoration(labelText: "Device nonce (POC)")),
            TextField(controller: attestSecretCtl, decoration: const InputDecoration(labelText: "POC attest secret")),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: genToken, child: const Text("Generate Token (POC)")),
            SelectableText("token: $token"),
            const Divider(),
            ElevatedButton(onPressed: announce, child: const Text("POST /presence/announce")),
            ElevatedButton(onPressed: kmetCall, child: const Text("GET /presence/kmet")),
            Row(children: [
              ElevatedButton(onPressed: getKey, child: const Text("POST /keys/request")),
              const SizedBox(width: 12),
              Expanded(child: SelectableText("room key (b64): $roomKeyB64")),
            ]),
            const Divider(),
            TextField(controller: messageCtl, decoration: const InputDecoration(labelText: "Message (base64 placeholder)")),
            Row(children: [
              ElevatedButton(onPressed: postMsg, child: const Text("POST /content/post")),
              const SizedBox(width: 12),
              ElevatedButton(onPressed: listMsg, child: const Text("GET /content/list")),
            ]),
            const SizedBox(height: 12),
            const Text("Output:"),
            SelectableText(output, minLines: 4),
          ],
        ),
      ),
    );
  }
}
