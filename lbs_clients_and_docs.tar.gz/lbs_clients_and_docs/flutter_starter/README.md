# Flutter Starter — LBS POC Client

This is a tiny Flutter app to exercise the Django POC endpoints.

## Run
```bash
flutter create lbs_poc_client
cd lbs_poc_client
# overwrite lib/main.dart and pubspec.yaml with the files from this folder
cp ../lib/main.dart lib/main.dart
cp ../pubspec.yaml pubspec.yaml

flutter pub get
flutter run -d chrome   # or ios/android device
```
By default it points to http://localhost:8000. If running on a device, point it to your machine IP.

## Notes
- Token generation uses the POC secret to mirror the server logic. In production, replace with blind tokens minted after device attestation.
- room key is displayed but not yet used; for real E2EE, derive a content key and encrypt with AES-GCM/MLS on-device.
