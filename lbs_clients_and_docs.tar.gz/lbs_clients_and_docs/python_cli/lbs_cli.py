#!/usr/bin/env python3
# A privacy-preserving location POC CLI client.
# - Converts (lat,lon) -> geohash (client-side), floors time to bucket
# - Generates a POC token (HMAC over device_nonce|bucket) -- demo only
# - Calls presence -> kmet -> key request -> encrypts a message with AES-GCM and posts
# - Lists messages and tries to decrypt them

import argparse, base64, hashlib, hmac, json, os, sys, time
from datetime import datetime, timezone
import requests
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

__base32 = "0123456789bcdefghjkmnpqrstuvwxyz"
def geohash_encode(lat: float, lon: float, precision: int) -> str:
    lat_interval = [-90.0, 90.0]
    lon_interval = [-180.0, 180.0]
    geohash = []
    is_even = True
    bit = 0
    ch = 0
    bits = [16,8,4,2,1]
    while len(geohash) < precision:
        if is_even:
            mid = (lon_interval[0] + lon_interval[1]) / 2
            if lon > mid:
                ch |= bits[bit]; lon_interval[0] = mid
            else:
                lon_interval[1] = mid
        else:
            mid = (lat_interval[0] + lat_interval[1]) / 2
            if lat > mid:
                ch |= bits[bit]; lat_interval[0] = mid
            else:
                lat_interval[1] = mid
        is_even = not is_even
        if bit < 4:
            bit += 1
        else:
            geohash.append(__base32[ch])
            bit = 0; ch = 0
    return "".join(geohash)

def bucket_time_iso(dt: datetime, minutes: int) -> str:
    minute = (dt.minute // minutes) * minutes
    return dt.replace(minute=minute, second=0, microsecond=0, tzinfo=timezone.utc).isoformat().replace("+00:00","Z")

def poc_token(attest_secret: str, device_nonce: str, bucket_iso: str) -> str:
    mac = hmac.new(attest_secret.encode(), f"{device_nonce}|{bucket_iso}".encode(), hashlib.sha256).hexdigest()
    raw = f"{device_nonce}|{bucket_iso}|{mac}"
    return base64.urlsafe_b64encode(raw.encode()).decode().rstrip("=")

def aesgcm_encrypt(key: bytes, plaintext: bytes, aad: bytes=b"") -> str:
    nonce = os.urandom(12)
    ct = AESGCM(key).encrypt(nonce, plaintext, aad)
    return base64.b64encode(nonce + ct).decode()

def aesgcm_decrypt(key: bytes, b64: str, aad: bytes=b"") -> bytes:
    data = base64.b64decode(b64)
    nonce, ct = data[:12], data[12:]
    return AESGCM(key).decrypt(nonce, ct, aad)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", default="http://localhost:8000")
    parser.add_argument("--lat", type=float, default=43.6535)
    parser.add_argument("--lon", type=float, default=-79.3839)
    parser.add_argument("--precision", type=int, default=6)
    parser.add_argument("--bucket-mins", type=int, default=10)
    parser.add_argument("--device-nonce", default="cli1")
    parser.add_argument("--attest-secret", default="attest-secret-change-me")
    parser.add_argument("--message", default="hello from the CLI POC")
    args = parser.parse_args()

    now = datetime.now(timezone.utc)
    cell = geohash_encode(args.lat, args.lon, args.precision)
    bucket = bucket_time_iso(now, args.bucket_mins)
    token = poc_token(args.attest_secret, args.device_nonce, bucket)

    print(f"[client] cell={cell} bucket={bucket}")

    r = requests.post(f"{args.server}/api/presence/announce", json={"cell":cell,"bucket":bucket,"token":token}, timeout=10)
    print("[presence]", r.status_code, r.text)

    r = requests.get(f"{args.server}/api/presence/kmet", params={"cell":cell,"bucket":bucket}, timeout=10)
    print("[kmet]", r.status_code, r.text)
    kdata = r.json()
    if not kdata.get("k_met"):
        print("[-] k not met; exiting")
        return

    r = requests.post(f"{args.server}/api/keys/request", json={"cell":cell,"bucket":bucket,"token":token}, timeout=10)
    print("[key]", r.status_code, r.text)
    key_b64 = r.json()["key_b64"]
    key = base64.b64decode(key_b64)[:32]

    ct_b64 = aesgcm_encrypt(key, args.message.encode(), aad=f"{cell}|{bucket}".encode())
    r = requests.post(f"{args.server}/api/content/post", json={"cell":cell,"bucket":bucket,"ciphertext_b64":ct_b64}, timeout=10)
    print("[post]", r.status_code, r.text)

    r = requests.get(f"{args.server}/api/content/list", params={"cell":cell,"bucket":bucket}, timeout=10)
    print("[list]", r.status_code)
    for i,p in enumerate(r.json()):
        try:
            pt = aesgcm_decrypt(key, p["ciphertext_b64"], aad=f"{cell}|{bucket}".encode()).decode(errors="ignore")
        except Exception as e:
            pt = f"(cannot decrypt: {e})"
        print(f"  #{i+1} {p['created_at']} -> {pt}")

if __name__ == "__main__":
    main()
