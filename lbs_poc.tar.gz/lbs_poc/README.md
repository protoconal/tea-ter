# Location POC (Non‑P2P) — Django + DRF (Dockerized)

This is a privacy‑preserving, **cell/time** based presence + key + content POC.
It does **not** use raw GPS server‑side. Clients send only `(cell, bucket)`.

## Components
- **Presence API**: anonymous presence announcements → per (cell,bucket) counters with k‑gating
- **Key API**: issues short‑lived read keys derived from `(cell,bucket)` (VOPRF placeholder)
- **Content API**: stores and lists ciphertexts per (cell,bucket)
- **Transparency**: signed headers publishing `(cell,bucket)` count/floor (stub)
- **Desktop UI**: minimal Django template to exercise flows manually

> ⚠️ Tokens & VOPRF here are **placeholders** for a POC. Replace with:
> - Blind tokens (Privacy Pass‑style) after device attestation
> - True VOPRF (e.g., RFC 9381 primitives) for key derivation

## Quick start (Docker)

```bash
# 0) ensure Docker is running
cd server
docker compose up --build

# In a second terminal (first run):
docker compose exec web python manage.py migrate
docker compose exec web python manage.py createsuperuser  # optional
```

Open: http://localhost:8000

- API root: `/api/`
- Minimal desktop UI: `/ui/`
