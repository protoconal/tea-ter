from django.db import models

class Presence(models.Model):
    cell = models.CharField(max_length=16, db_index=True)
    bucket = models.CharField(max_length=32, db_index=True)   # ISO string (UTC, floored)
    device_nonce = models.CharField(max_length=64, db_index=True)  # pseudonymous, per-device
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("device_nonce", "bucket")

class EncryptedPost(models.Model):
    cell = models.CharField(max_length=16, db_index=True)
    bucket = models.CharField(max_length=32, db_index=True)
    ciphertext_b64 = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
