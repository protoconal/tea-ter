from django.urls import path
from .views import PresenceAnnounceView, KMetView, KeyRequestView, PostCreateView, PostListView, TransparencyHeaderView

urlpatterns = [
    path("presence/announce", PresenceAnnounceView.as_view()),
    path("presence/kmet", KMetView.as_view()),
    path("keys/request", KeyRequestView.as_view()),
    path("content/post", PostCreateView.as_view()),
    path("content/list", PostListView.as_view()),
    path("transparency/header", TransparencyHeaderView.as_view()),
]
