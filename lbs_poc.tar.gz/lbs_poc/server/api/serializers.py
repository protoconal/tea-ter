from rest_framework import serializers

class PresenceAnnounceSerializer(serializers.Serializer):
    cell = serializers.CharField(max_length=16)
    bucket = serializers.CharField(max_length=32)
    token = serializers.CharField(max_length=256)

class KMetQuerySerializer(serializers.Serializer):
    cell = serializers.CharField(max_length=16)
    bucket = serializers.CharField(max_length=32)

class KeyRequestSerializer(serializers.Serializer):
    cell = serializers.CharField(max_length=16)
    bucket = serializers.CharField(max_length=32)
    token = serializers.CharField(max_length=256)

class PostCreateSerializer(serializers.Serializer):
    cell = serializers.CharField(max_length=16)
    bucket = serializers.CharField(max_length=32)
    ciphertext_b64 = serializers.CharField()
