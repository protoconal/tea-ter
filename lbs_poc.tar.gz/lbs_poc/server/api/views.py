import base64, hmac, hashlib, time, json
from typing import Tuple
from django.conf import settings
from django.db.models import Count
from django.db import IntegrityError
from django.shortcuts import render
from ratelimit.decorators import ratelimit
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .models import Presence, EncryptedPost
from .serializers import (
    PresenceAnnounceSerializer, KMetQuerySerializer, KeyRequestSerializer, PostCreateSerializer
)

def verify_poc_token(token: str):
    """
    POC token format (NOT for prod):
    base64url( device_nonce | '|' | bucket | '|' | HMAC(ATTEST_SECRET, device_nonce+'|'+bucket) )
    Returns (ok, device_nonce)
    """
    try:
        raw = base64.urlsafe_b64decode(token.encode("utf-8")).decode("utf-8")
        device_nonce, bucket, mac = raw.split("|")
        expected = hmac.new(settings.ATTEST_SECRET.encode(), f"{device_nonce}|{bucket}".encode(), hashlib.sha256).hexdigest()
        if hmac.compare_digest(expected, mac):
            return True, device_nonce
    except Exception:
        pass
    return False, ""

def derive_room_key(cell: str, bucket: str) -> bytes:
    prk = hmac.new(settings.SERVER_SECRET.encode(), f"{cell}|{bucket}".encode(), hashlib.sha256).digest()
    okm = hmac.new(prk, b"room-read", hashlib.sha256).digest()
    return okm

def sign_header(payload: dict) -> str:
    msg = json.dumps(payload, sort_keys=True).encode()
    sig = hmac.new(settings.SERVER_SECRET.encode(), msg, hashlib.sha256).digest()
    return base64.b64encode(sig).decode()

def ui_home(request):
    return render(request, "ui.html", context={})

class PresenceAnnounceView(APIView):
    @ratelimit(key='ip', rate='60/m', block=True)
    def post(self, request):
        s = PresenceAnnounceSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        cell = s.validated_data["cell"]
        bucket = s.validated_data["bucket"]
        token = s.validated_data["token"]
        ok, device_nonce = verify_poc_token(token)
        if not ok:
            return Response({"error": "invalid_token"}, status=400)
        try:
            Presence.objects.create(cell=cell, bucket=bucket, device_nonce=device_nonce)
        except IntegrityError:
            pass
        return Response({"ok": True})

class KMetView(APIView):
    def get(self, request):
        s = KMetQuerySerializer(data=request.query_params)
        s.is_valid(raise_exception=True)
        cell = s.validated_data["cell"]
        bucket = s.validated_data["bucket"]
        k = settings.K_MIN
        count = Presence.objects.filter(cell=cell, bucket=bucket).values("device_nonce").distinct().count()
        k_met = count >= k
        floor = f">={k}" if k_met else f"<{k}"
        header = {"cell": cell, "bucket": bucket, "floor": floor, "ts": int(time.time())}
        sig = sign_header(header)
        return Response({"k_met": k_met, "floor": floor, "header": header, "header_sig": sig})

class KeyRequestView(APIView):
    @ratelimit(key='ip', rate='60/m', block=True)
    def post(self, request):
        s = KeyRequestSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        cell = s.validated_data["cell"]
        bucket = s.validated_data["bucket"]
        token = s.validated_data["token"]
        ok, device_nonce = verify_poc_token(token)
        if not ok:
            return Response({"error": "invalid_token"}, status=400)
        k = settings.K_MIN
        count = Presence.objects.filter(cell=cell, bucket=bucket).values("device_nonce").distinct().count()
        if count < k:
            return Response({"error": "k_not_met"}, status=403)
        key = derive_room_key(cell, bucket)
        header = {"cell": cell, "bucket": bucket, "floor": f">={k}", "ts": int(time.time())}
        sig = sign_header(header)
        return Response({"key_b64": base64.b64encode(key).decode(), "header": header, "header_sig": sig})

class PostCreateView(APIView):
    @ratelimit(key='ip', rate='120/m', block=True)
    def post(self, request):
        s = PostCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        EncryptedPost.objects.create(**s.validated_data)
        return Response({"ok": True}, status=201)

class PostListView(APIView):
    def get(self, request):
        s = KMetQuerySerializer(data=request.query_params)
        s.is_valid(raise_exception=True)
        qs = EncryptedPost.objects.filter(cell=s.validated_data["cell"], bucket=s.validated_data["bucket"]).order_by("created_at")
        return Response([{ "ciphertext_b64": p.ciphertext_b64, "created_at": p.created_at.isoformat()} for p in qs])

class TransparencyHeaderView(APIView):
    def get(self, request):
        s = KMetQuerySerializer(data=request.query_params)
        s.is_valid(raise_exception=True)
        cell = s.validated_data["cell"]
        bucket = s.validated_data["bucket"]
        count = Presence.objects.filter(cell=cell, bucket=bucket).values("device_nonce").distinct().count()
        header = {"cell": cell, "bucket": bucket, "count": count, "ts": int(time.time())}
        sig = sign_header(header)
        return Response({"header": header, "header_sig": sig})
